import os
import pandas as pd
import numpy as np
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.probability import FreqDist
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
from itertools import combinations
from scipy.stats import pearsonr
import re

# Punto 1: Proceso de limpieza y guardar documentos en archivos
def limpiar_texto(texto):
    texto_limpio = re.sub(r'[^\w\s]', '', texto)
    texto_limpio = texto_limpio.lower()  # Convertir todo a minúsculas
    return texto_limpio

# Lee los textos desde archivos y realiza la limpieza
carpeta_textos = "../Webscraping/Textos"

textos = []
for archivo in os.listdir(carpeta_textos):
    if archivo.endswith(".txt"):
        with open(os.path.join(carpeta_textos, archivo), "r", encoding="utf-8") as archivo_txt:
            texto = archivo_txt.read()
            texto_limpio = limpiar_texto(texto)
            textos.append(texto_limpio)

# Punto 2: Identificar cantidad de palabras sin repetir

def contar_palabras_sin_repeticion(texto):
    palabras = word_tokenize(texto)
    palabras_sin_repeticion = set(palabras)
    return len(palabras_sin_repeticion)

cantidad_palabras_sin_repeticion = [contar_palabras_sin_repeticion(texto) for texto in textos]

# Punto 3: Promedio y desviación estándar de las palabras
promedio_palabras = np.mean(cantidad_palabras_sin_repeticion)
desviacion_estandar_palabras = np.std(cantidad_palabras_sin_repeticion)

# Punto 4: Identificar las 50 palabras más usadas y guardar en archivo
def obtener_palabras_mas_usadas(texto, n=50):
    palabras = word_tokenize(texto.lower())
    palabras_sin_stopwords = [palabra for palabra in palabras if palabra not in stopwords.words('spanish')]
    frecuencia_palabras = FreqDist(palabras_sin_stopwords)
    palabras_mas_usadas = [palabra for palabra, frecuencia in frecuencia_palabras.most_common(n)]
    return palabras_mas_usadas

for i, texto in enumerate(textos):
    palabras_mas_usadas = obtener_palabras_mas_usadas(texto, n=50)
    with open(f"palabras_mas_usadas_documento_{i}.txt", "w", encoding="utf-8") as archivo:
        archivo.write("\n".join(palabras_mas_usadas))

# Punto 5: Grafico de palabras más usadas y nube de palabras
def generar_nube_palabras(texto):
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(texto)
    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud, interpolation="bilinear")
    plt.axis('off')
    plt.show()

texto_completo = " ".join(textos)
generar_nube_palabras(texto_completo)

# Punto 6: Análisis de correlación entre textos
def calcular_correlacion(texto1, texto2):
    palabras_texto1 = set(word_tokenize(texto1.lower()))
    palabras_texto2 = set(word_tokenize(texto2.lower()))
    
    palabras_comunes = palabras_texto1.intersection(palabras_texto2)
    palabras_totales = palabras_texto1.union(palabras_texto2)
    
    correlacion = len(palabras_comunes) / len(palabras_totales)
    return correlacion

correlaciones = np.zeros((len(textos), len(textos)))
for i, j in combinations(range(len(textos)), 2):
    correlacion = calcular_correlacion(textos[i], textos[j])
    correlaciones[i, j] = correlacion
    correlaciones[j, i] = correlacion

# Punto 7: Comparar palabras más comunes entre documentos con correlación del 80%
indice_correlacion_80 = np.where(correlaciones >= 0.8)
palabras_comunes_correlacion_80 = set()
for i, j in zip(*indice_correlacion_80):
    palabras_i = obtener_palabras_mas_usadas(textos[i], n=50)
    palabras_j = obtener_palabras_mas_usadas(textos[j], n=50)
    palabras_comunes_correlacion_80.update(palabras_i)
    palabras_comunes_correlacion_80.intersection_update(palabras_j)

# Punto 8: Análisis de palabras más diferenciadas por cada usuario usando log of odds ratio
def calcular_log_odds_ratio(texto1, texto2):
    # Tokenizamos los textos y los convertimos a minúsculas
    palabras_texto1 = word_tokenize(texto1.lower())
    palabras_texto2 = word_tokenize(texto2.lower())

    # Creamos conjuntos para eliminar las palabras duplicadas
    palabras_set_texto1 = set(palabras_texto1)
    palabras_set_texto2 = set(palabras_texto2)

    # Calculamos la proporción de palabras en cada texto
    p_palabra_texto1 = len(palabras_set_texto1) / len(palabras_texto1)
    p_palabra_texto2 = len(palabras_set_texto2) / len(palabras_texto2)

    # Calculamos la proporción de palabras en otros documentos
    otras_palabras = palabras_set_texto1.union(palabras_set_texto2)
    p_palabra_otros_documentos = len(otras_palabras) / (len(palabras_texto1) + len(palabras_texto2))

    # Calculamos el log odds ratio
    log_odds_ratio = np.log(p_palabra_texto1 / p_palabra_otros_documentos) - np.log(p_palabra_texto2 / p_palabra_otros_documentos)

    return log_odds_ratio

palabras_log_odds_ratio = {}
for i, j in combinations(range(len(textos)), 2):
    log_odds_ratio = calcular_log_odds_ratio(textos[i], textos[j])
    palabras_log_odds_ratio[(i, j)] = log_odds_ratio

# Obtener las 100 palabras con mayor log of odds ratio por cada documento
top_100_palabras_log_odds_ratio = {}
for documento in range(len(textos)):
    palabras_documentos = [(i, j) for (i, j), palabra_log_odds in palabras_log_odds_ratio.items() if i == documento or j == documento]
    top_100_palabras_documentos = sorted(palabras_documentos, key=lambda x: palabras_log_odds_ratio[x], reverse=True)[:100]
    top_100_palabras_log_odds_ratio[documento] = top_100_palabras_documentos



# Mapa de calor de correlaciones
plt.figure(figsize=(8, 6))
sns.heatmap(correlaciones, annot=True, cmap="coolwarm", xticklabels=range(len(textos)), yticklabels=range(len(textos)))
plt.title("Matriz de correlación entre textos")
plt.xlabel("Documento")
plt.ylabel("Documento")
plt.show()

# Mostrar palabras más comunes entre documentos con correlación >= 0.8
print("Palabras más comunes entre documentos con correlación >= 0.8:")
print(palabras_comunes_correlacion_80)
