import os
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, make_scorer

def clean_text(text):
    # Convertir el texto a minúsculas
    text = text.lower()
    
    # Eliminar caracteres especiales y números
    text = re.sub(r'[^\w\s]', '', text)
    
    # Tokenización
    tokens = nltk.word_tokenize(text)
    
    # Eliminar stopwords
    stop_words = set(stopwords.words('spanish'))
    filtered_tokens = [word for word in tokens if word not in stop_words]
    
    # Lematización
    lemmatizer = WordNetLemmatizer()
    lemmatized_tokens = [lemmatizer.lemmatize(word) for word in filtered_tokens]
    
    # Unir tokens limpios en un solo texto
    cleaned_text = " ".join(lemmatized_tokens)
    
    return cleaned_text

# Ruta de la carpeta con los archivos de texto
ruta_carpeta = "../Webscraping/Textos"

# Lista para almacenar el texto limpio
textos_limpios = []
etiquetas = ['etiqueta1', 'etiqueta2', 'etiqueta3', 'etiqueta4', 'etiqueta5', 'etiqueta6','etiqueta1', 'etiqueta2', 'etiqueta3', 'etiqueta4', 'etiqueta5', 'etiqueta6','etiqueta1', 'etiqueta2', 'etiqueta3', 'etiqueta4', 'etiqueta5', 'etiqueta6','etiqueta1','etiqueta2']

# Número máximo de palabras en cada archivo
max_palabras = 300

# Recorrer todos los archivos en la carpeta
for archivo in os.listdir(ruta_carpeta):
    # Leer el contenido del archivo
    with open(os.path.join(ruta_carpeta, archivo), "r", encoding="utf-8") as file:
        texto = file.read()
    
    # Limpiar el texto y aplicar lematización
    texto_limpio = clean_text(texto)
    
    # Limitar la cantidad de palabras
    texto_palabras = texto_limpio.split()[:max_palabras]
    texto_limite_palabras = " ".join(texto_palabras)
    
    # Agregar el texto limpio y limitado a la lista
    textos_limpios.append(texto_limite_palabras)

# Definir el lexicón
lexicón = ['cuidado', 'salud', 'mascota', 'veterinario', 'vacuna', 'alimentación',
           'ejercicio', 'higiene', 'enfermedad', 'prevención']

# Función para determinar si un documento está relacionado con el léxico
def documento_relacionado(documento, lexicón):
    palabras_documento = documento.split()
    return any(palabra in lexicón for palabra in palabras_documento)

# Extraer solo aquellos documentos relacionados con el Lexicon
documentos_relacionados = [texto for texto in textos_limpios if documento_relacionado(texto, lexicón)]

# Identificar puntaje de la suma y promedio para cada tema
puntajes_suma_temas = {tema: 0 for tema in etiquetas}
puntajes_promedio_temas = {tema: 0 for tema in etiquetas}

for documento in documentos_relacionados:
    palabras_documento = documento.split()
    puntaje_documento = sum(palabra in lexicón for palabra in palabras_documento)
    for tema in etiquetas:
        if tema in documento:
            puntajes_suma_temas[tema] += puntaje_documento
            puntajes_promedio_temas[tema] += puntaje_documento / len(documentos_relacionados)

# Identificar puntaje de la suma y promedio para cada documento
puntajes_suma_documentos = [sum(palabra in lexicón for palabra in documento.split()) for documento in documentos_relacionados]
puntajes_promedio_documentos = [puntaje / len(lexicón) for puntaje in puntajes_suma_documentos]

# Discretizar cada documento en negativo, neutro, positivo
umbral_negativo = 1
umbral_positivo = 3

documentos_discretizados = []
for puntaje in puntajes_suma_documentos:
    if puntaje < umbral_negativo:
        documentos_discretizados.append('negativo')
    elif puntaje >= umbral_negativo and puntaje <= umbral_positivo:
        documentos_discretizados.append('neutro')
    else:
        documentos_discretizados.append('positivo')

vectorizador = TfidfVectorizer()
tfidf_matrix = vectorizador.fit_transform(documentos_relacionados)

# SVM
svm_model = SVC(kernel='linear', C=1.0, random_state=42)
cv_stratified = StratifiedKFold(n_splits=2, shuffle=True, random_state=42)

# Definir una métrica personalizada con zero_division=1
precision_scorer = make_scorer(precision_score, average='weighted', zero_division=1)
recall_scorer = make_scorer(recall_score, average='weighted', zero_division=1)
f1_scorer = make_scorer(f1_score, average='weighted', zero_division=1)

scores_svm = cross_val_score(svm_model, tfidf_matrix, documentos_discretizados, cv=cv_stratified, scoring='accuracy')
accuracy_svm_cv = scores_svm.mean()
precision_svm_cv = cross_val_score(svm_model, tfidf_matrix, documentos_discretizados, cv=cv_stratified, scoring=precision_scorer).mean()
recall_svm_cv = cross_val_score(svm_model, tfidf_matrix, documentos_discretizados, cv=cv_stratified, scoring=recall_scorer).mean()
f1_svm_cv = cross_val_score(svm_model, tfidf_matrix, documentos_discretizados, cv=cv_stratified, scoring=f1_scorer).mean()

# Naive Bayes
nb_model = MultinomialNB()
scores_nb = cross_val_score(nb_model, tfidf_matrix, documentos_discretizados, cv=cv_stratified, scoring='accuracy')
accuracy_nb_cv = scores_nb.mean()
precision_nb_cv = cross_val_score(nb_model, tfidf_matrix, documentos_discretizados, cv=cv_stratified, scoring=precision_scorer).mean()
recall_nb_cv = cross_val_score(nb_model, tfidf_matrix, documentos_discretizados, cv=cv_stratified, scoring=recall_scorer).mean()
f1_nb_cv = cross_val_score(nb_model, tfidf_matrix, documentos_discretizados, cv=cv_stratified, scoring=f1_scorer).mean()

# Resultados con validación cruzada
print("Resultados SVM con validación cruzada:")
print("Accuracy:", accuracy_svm_cv)
print("Precision:", precision_svm_cv)
print("Recall:", recall_svm_cv)
print("F1-Score:", f1_svm_cv)

print("\nResultados Naive Bayes con validación cruzada:")
print("Accuracy:", accuracy_nb_cv)
print("Precision:", precision_nb_cv)
print("Recall:", recall_nb_cv)
print("F1-Score:", f1_nb_cv)

