import os
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

nltk.download('wordnet')
nltk.download('punkt')

def clean_text(text):
    # Convertir el texto a minúsculas
    text = text.lower()
    
    # Eliminar caracteres especiales y números
    text = re.sub(r'[^\w\s]', '', text)
    
    # Tokenización
    tokens = nltk.word_tokenize(text)
    
    # Eliminar stopwords
    stop_words = set(stopwords.words('spanish'))
    filtered_tokens = [word for word in tokens if word not in stop_words]
    
    # Unir tokens limpios en un solo texto
    cleaned_text = " ".join(filtered_tokens)
    
    return cleaned_text

def lemmatize_text(text):
    lemmatizer = WordNetLemmatizer()
    words = nltk.word_tokenize(text)
    lemmatized_words = [lemmatizer.lemmatize(word) for word in words]
    lemmatized_text = " ".join(lemmatized_words)
    return lemmatized_text

# Ruta de la carpeta con los archivos de texto
ruta_carpeta = "../Webscraping/Textos"

# Lista para almacenar el texto limpio
textos_limpios = []
etiquetas = ['etiqueta1', 'etiqueta2', 'etiqueta3', 'etiqueta4', 'etiqueta5', 'etiqueta6','etiqueta1', 'etiqueta2', 'etiqueta3', 'etiqueta4', 'etiqueta5', 'etiqueta6','etiqueta1', 'etiqueta2', 'etiqueta3', 'etiqueta4', 'etiqueta5', 'etiqueta6','etiqueta1','etiqueta2']

# Número máximo de palabras en cada archivo
max_palabras = 300

# Recorrer todos los archivos en la carpeta
for archivo in os.listdir(ruta_carpeta):
    # Leer el contenido del archivo
    with open(os.path.join(ruta_carpeta, archivo), "r", encoding="utf-8") as file:
        texto = file.read()
    
    # Limpiar el texto
    texto_limpio = clean_text(texto)
    
    # Limitar la cantidad de palabras
    texto_palabras = texto_limpio.split()[:max_palabras]
    texto_limite_palabras = " ".join(texto_palabras)
    
    # Agregar el texto limpio y limitado a la lista
    textos_limpios.append(texto_limite_palabras)

# Aplicar lematización a los textos limpios
textos_lemmatized = [lemmatize_text(texto) for texto in textos_limpios]

# Crear un vectorizador TF-IDF para training & testing
vectorizer_tfidf = TfidfVectorizer()

# Obtener la matriz de características para training & testing
tfidf_matrix = vectorizer_tfidf.fit_transform(textos_lemmatized)

# Divide los datos en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(tfidf_matrix, etiquetas, test_size=0.2, random_state=42)

# Entrenar el algoritmo SVM para training & testing
svm_tfidf = SVC(kernel='linear', C=1.0, random_state=42)
svm_tfidf.fit(X_train, y_train)

# Predecir con el conjunto de prueba
y_pred = svm_tfidf.predict(X_test)

# Evaluar el rendimiento
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, average='macro',zero_division=1)
recall = recall_score(y_test, y_pred, average='macro',zero_division=1)
f1 = f1_score(y_test, y_pred, average='macro')

print("SVM Accuracy:", accuracy)
print("SVM Precision:", precision)
print("SVM Recall:", recall)
print("SVM F1-Score:", f1)

# Crear un vectorizador TF-IDF para cross-validation
vectorizer_cv = TfidfVectorizer()

# Obtener la matriz de características para cross-validation
tfidf_matrix_cv = vectorizer_cv.fit_transform(textos_lemmatized)

# Entrenar el algoritmo SVM para cross-validation
svm_tfidf_cv = SVC(kernel='linear', C=1.0, random_state=42)

# Realizar cross-validation con 5 folds
cv_stratified = StratifiedKFold(n_splits=2, shuffle=True, random_state=10)
scores_tfidf_cv = cross_val_score(svm_tfidf_cv, tfidf_matrix_cv, etiquetas, cv=cv_stratified)

# Obtener el rendimiento promedio para cross-validation
mean_accuracy_tfidf_cv = scores_tfidf_cv.mean()
print("SVM Mean Accuracy (Cross-validation):", mean_accuracy_tfidf_cv)

# Entrenar el algoritmo Naive Bayes para cross-validation
nb_tfidf_cv = MultinomialNB()

# Realizar cross-validation con 5 folds
scores_nb_cv = cross_val_score(nb_tfidf_cv, tfidf_matrix_cv, etiquetas, cv=cv_stratified)

# Obtener el rendimiento promedio para cross-validation
mean_accuracy_nb_cv = scores_nb_cv.mean()
print("Naive Bayes Mean Accuracy (Cross-validation):", mean_accuracy_nb_cv)
