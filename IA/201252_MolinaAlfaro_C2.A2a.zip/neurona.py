import numpy as np
import math as m
import matplotlib.pyplot as plt
import pandas as pd

import tkinter as tk
from tkinter import messagebox as mb
from tkinter import filedialog
from tkinter.ttk import Treeview
from tkinter import ttk
from tkinter import *

class Perceptron ():

    def readCsv(self,archivo):
        df = pd.read_csv(archivo, delimiter=';')
        x = df.iloc[:, 0:3].values
        y = df.iloc[:, 3].values
        x = self.bias(x)
        self.X = x
        self.Y = y
        self.pesos = np.random.rand(len(x[0]))
        print("Pesos iniciales:", self.pesos)


    def bias(self, x):
        return np.insert(x, 0, 1, axis=1)

    def calcularU(self):
        return np.dot(self.X, self.pesos)

    def funcionActivacion(self, u):
        return u
    
    def error(self, yCalculada):
        return [self.Y[i] - yCalculada[i] for i in range(len(yCalculada))]

    def errorAbsoluto(self, error):
            mse = np.mean(np.square(error))
            rmse = m.sqrt(mse)
            return rmse

    def deltaW(self, e):
        ret = np.transpose(e)
        return np.dot(ret, self.X) * self.aprendizaje
    
    def nv_W(self, deltaW):
        self.pesos += deltaW
        return self.pesos

    
        
def algoritmo(aprendizaje, Error, archivo, iter):
    
    perceptron = Perceptron(aprendizaje, Error)
    a = str(aprendizaje)
    errores = []
    pesosSesgo = []
    pesosX1 = []
    pesosX2 = []
    pesosX3 = []
    perceptron.readCsv(archivo)
    
    for i in range(iter):
        u = perceptron.calcularU()
        yCalculada = perceptron.funcionActivacion(u)
        error = perceptron.error(yCalculada)
        deltaW = perceptron.deltaW(error)
        pesosSesgo.append(perceptron.pesos[0])
        pesosX1.append(perceptron.pesos[1])
        pesosX2.append(perceptron.pesos[2])
        pesosX3.append(perceptron.pesos[3])
        perceptron.nv_W(deltaW)
        e = perceptron.errorAbsoluto(error)
        errores.append(e)
        print('Generacion:', i)
    
    print("errores:", errores)
    print("Pesos finales:", perceptron.pesos)
    print("Error observado:", max(errores))
    pesos = [pesosSesgo, pesosX1, pesosX2, pesosX3]
    graficar(errores, pesos, a, iter)  

def graficar(errores, pesos, a, iter):
        plt.title("Evolución de la media del error - {} iteraciones".format(iter))
        plt.xlabel("Iteracion")
        plt.ylabel("Valor del error")
        plt.plot(errores, label="TA:"+a, linestyle="-")
        plt.legend()
        plt.show()

        plt.title("Evolución de los pesos")
        plt.ylabel("Valor")
        plt.plot(pesos[0], label="W0", color="blue", linestyle="-")
        plt.plot(pesos[1], label="W1", color="green", linestyle="-")
        plt.plot(pesos[2], label="W2", color="red", linestyle="-")
        plt.plot(pesos[3], label="W3", color="black", linestyle="-")
        plt.legend()
        plt.show()

    
def abrirArchivo():
    fileopen = filedialog.askopenfilename(
        initialdir="./",
        title="Seleccion de dataset csv",
        filetypes=(("Csv files", "*.csv"), ("All documents", "*.*")),
    )
    print(fileopen)
    neurona(fileopen)

def neurona(archivo):
    salida = True

    try:
        aprendizaje = float(entry_aprendizaje.get())
        Error = float(entry_Error.get())
        iter = int(entry_num_iteraciones.get())
        if(aprendizaje > 1 or aprendizaje <= 0):
            label_mensaje.config(text="El valor de aprendizaje debe estar entre 0 y 1", fg="red")
            salida = False
        if(Error <= 0):
            label_mensaje.config(text="El valor del Error debe ser mayor a 0", fg="red")
            salida = False
        if(archivo == ""):
            label_mensaje.config(text="Seleccione un archivo", fg="red")
            salida = False
        if(iter == ""):
            label_mensaje.config(text="Ingrese un número válido para Iteraciones", fg="red")
            salida = False
            
    except:
        salida = False
        
    if salida:
        nombre = archivo.split("/")
        nombre = nombre[len(nombre)-1].split(".")
        label_mensaje.config(text="Generando Gráficas "+str(nombre[0]), fg="black")
        scene.update()
        algoritmo(aprendizaje, Error, archivo, iter)

def __init__(self,aprendizaje, Error):
        self.aprendizaje = aprendizaje
        self.Error = Error
        self.pesos = []
        self.error = 0
        self.X = []
        self.Y = []

if __name__ == '__main__':
    scene = tk.Tk()
    scene.title("Seleccion de dataset csv")
    scene.geometry('400x300')
    scene.resizable(width=False, height=False)

    canvas = Canvas(scene, width=320, height=320)
    canvas.create_text(160, 100, text="Busque su dataset csv", fill="black", font=('Helvetica 15'))
    Button(scene, text="Agregar archivo", command=abrirArchivo).place(relx=0.5, rely=0.5, width=100, anchor='c')

    label_aprendizaje = tk.Label(scene, text="Aprendizaje:")
    label_error = tk.Label(scene, text="Error:")
    entry_aprendizaje = tk.Entry(scene)
    entry_Error = tk.Entry(scene)

    label_aprendizaje.place(relx=0.5, rely=0.6, anchor='c')
    entry_aprendizaje.place(relx=0.5, rely=0.65, anchor='c')
    label_error.place(relx=0.5, rely=0.7, anchor='c')
    entry_Error.place(relx=0.5, rely=0.75, anchor='c')
    label_num_iteraciones = tk.Label(scene, text="Número de Iteraciones:")
    entry_num_iteraciones = tk.Entry(scene)
    label_num_iteraciones.place(relx=0.5, rely=0.8, anchor='c')
    entry_num_iteraciones.place(relx=0.5, rely=0.85, anchor='c')
    label_mensaje = tk.Label(scene, text="")
    label_mensaje.place(relx=0.5, rely=0.9, anchor='c')

    canvas.pack()
    scene.mainloop()
