class Repisa:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
        self.longitud = 3
        self.anchura = 1
        self.altura = 1
        self.paquetes = []
        self.color = 'black'